import React from 'react';

const App = () => (
    <div>
        <head>
            <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.min.css" rel="stylesheet" />
        </head>
        <body>
            <h1>Hello, React!</h1>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/js/bootstrap.bundle.min.js"></script>
        </body>
    </div>
);

export default App;
